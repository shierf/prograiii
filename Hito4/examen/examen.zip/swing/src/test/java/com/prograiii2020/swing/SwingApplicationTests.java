package com.prograiii2020.swing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SwingApplicationTests {

	@Test
	void contextLoads() {
	}

}
